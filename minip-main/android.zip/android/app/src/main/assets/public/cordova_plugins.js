
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-plugin-device.device",
          "file": "plugins/cordova-plugin-device/www/device.js",
          "pluginId": "cordova-plugin-device",
        "clobbers": [
          "device"
        ]
        },
      {
          "id": "cordova-plugin-fcm-with-dependecy-updated.FCMPlugin",
          "file": "plugins/cordova-plugin-fcm-with-dependecy-updated/www/FCMPlugin.js",
          "pluginId": "cordova-plugin-fcm-with-dependecy-updated",
        "clobbers": [
          "FCM"
        ]
        },
      {
          "id": "cordova-plugin-nativegeocoder.NativeGeocoder",
          "file": "plugins/cordova-plugin-nativegeocoder/www/NativeGeocoder.js",
          "pluginId": "cordova-plugin-nativegeocoder",
        "clobbers": [
          "nativegeocoder"
        ]
        },
      {
          "id": "cordova-plugin-geolocation.geolocation",
          "file": "plugins/cordova-plugin-geolocation/www/android/geolocation.js",
          "pluginId": "cordova-plugin-geolocation",
        "clobbers": [
          "navigator.geolocation"
        ]
        },
      {
          "id": "cordova-sms-plugin.Sms",
          "file": "plugins/cordova-sms-plugin/www/sms.js",
          "pluginId": "cordova-sms-plugin",
        "clobbers": [
          "window.sms"
        ]
        },
      {
          "id": "cordova-plugin-statusbar.statusbar",
          "file": "plugins/cordova-plugin-statusbar/www/statusbar.js",
          "pluginId": "cordova-plugin-statusbar",
        "clobbers": [
          "window.StatusBar"
        ]
        },
      {
          "id": "cordova-plugin-geolocation.PositionError",
          "file": "plugins/cordova-plugin-geolocation/www/PositionError.js",
          "pluginId": "cordova-plugin-geolocation",
        "runs": true
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "cordova-plugin-androidx": "3.0.0",
      "cordova-plugin-androidx-adapter": "1.1.3",
      "cordova-plugin-device": "2.0.2",
      "cordova-plugin-fcm-with-dependecy-updated": "7.3.1",
      "cordova-plugin-geolocation": "4.0.2",
      "cordova-plugin-nativegeocoder": "3.4.1",
      "cordova-plugin-statusbar": "2.4.2",
      "cordova-plugin-whitelist": "1.3.3",
      "cordova-sms-plugin": "1.0.0"
    };
    // BOTTOM OF METADATA
    });
    