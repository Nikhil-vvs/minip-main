(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["uploader-uploader-module"], {
    /***/
    "8pe8":
    /*!*********************************************!*\
      !*** ./src/app/uploader/uploader.module.ts ***!
      \*********************************************/

    /*! exports provided: UploaderPageModule */

    /***/
    function pe8(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "UploaderPageModule", function () {
        return UploaderPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _uploader_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./uploader-routing.module */
      "Cx4w");
      /* harmony import */


      var _uploader_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./uploader.page */
      "SZJ6");

      var UploaderPageModule = function UploaderPageModule() {
        _classCallCheck(this, UploaderPageModule);
      };

      UploaderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _uploader_routing_module__WEBPACK_IMPORTED_MODULE_5__["UploaderPageRoutingModule"]],
        declarations: [_uploader_page__WEBPACK_IMPORTED_MODULE_6__["UploaderPage"]]
      })], UploaderPageModule);
      /***/
    },

    /***/
    "Cx4w":
    /*!*****************************************************!*\
      !*** ./src/app/uploader/uploader-routing.module.ts ***!
      \*****************************************************/

    /*! exports provided: UploaderPageRoutingModule */

    /***/
    function Cx4w(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "UploaderPageRoutingModule", function () {
        return UploaderPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _uploader_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./uploader.page */
      "SZJ6");

      var routes = [{
        path: '',
        component: _uploader_page__WEBPACK_IMPORTED_MODULE_3__["UploaderPage"]
      }];

      var UploaderPageRoutingModule = function UploaderPageRoutingModule() {
        _classCallCheck(this, UploaderPageRoutingModule);
      };

      UploaderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], UploaderPageRoutingModule);
      /***/
    },

    /***/
    "Kprk":
    /*!*********************************************!*\
      !*** ./src/app/uploader/uploader.page.scss ***!
      \*********************************************/

    /*! exports provided: default */

    /***/
    function Kprk(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".camera {\n  width: 400px;\n  height: 400px;\n  margin: 0 auto;\n  background: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXBsb2FkZXIvdXBsb2FkZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUFDSiIsImZpbGUiOiJzcmMvYXBwL3VwbG9hZGVyL3VwbG9hZGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jYW1lcmEge1xyXG4gICAgd2lkdGg6IDQwMHB4O1xyXG4gICAgaGVpZ2h0OiA0MDBweDtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gICAgYmFja2dyb3VuZDogYmxhY2s7XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "NjTV":
    /*!***********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/uploader/uploader.page.html ***!
      \***********************************************************************************/

    /*! exports provided: default */

    /***/
    function NjTV(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>uploader</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n <div class=\"camera\"></div>\n <input type=\"file\" *ngIf=\"!imageURL\" (change)=\"fileChanged($event)\"/>\n <ion-card>\n    <img *ngIf=\"imageURL\" src=\"https://ucarecdn.com/{{ imageURL }}/\" />\n    <ion-card-content>\n      <ion-textarea placeholder=\"Enter some description\" [(ngModel)]=\"desc\"></ion-textarea>\n      <ion-button shape=\"round\" color=\"primary\" (click)=\"createPost()\">POST</ion-button>\n    </ion-card-content>\n  </ion-card>\n</ion-content>\n";
      /***/
    },

    /***/
    "SZJ6":
    /*!*******************************************!*\
      !*** ./src/app/uploader/uploader.page.ts ***!
      \*******************************************/

    /*! exports provided: UploaderPage */

    /***/
    function SZJ6(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "UploaderPage", function () {
        return UploaderPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_uploader_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./uploader.page.html */
      "NjTV");
      /* harmony import */


      var _uploader_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./uploader.page.scss */
      "Kprk");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/fire/firestore */
      "I/3d");
      /* harmony import */


      var _user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../user.service */
      "xdv0");
      /* harmony import */


      var _angular_fire_database__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/fire/database */
      "sSZD");

      var UploaderPage = /*#__PURE__*/function () {
        function UploaderPage(http, afstore, user, afdb) {
          _classCallCheck(this, UploaderPage);

          this.http = http;
          this.afstore = afstore;
          this.user = user;
          this.afdb = afdb;
        }

        _createClass(UploaderPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "fileChanged",
          value: function fileChanged(event) {
            var _this = this;

            var files = event.target.files;
            var data = new FormData();
            data.append('file', files[0]);
            data.append('UPLOADCARE_STORE', '1');
            data.append('UPLOADCARE_PUB_KEY', '49dda3a43942eea5f56b');
            this.http.post('https://upload.uploadcare.com/base/', data).subscribe(function (event) {
              console.log(event);
              _this.imageURL = event['file'];
            });
          }
        }, {
          key: "createPost",
          value: function createPost() {
            var image = this.imageURL;
            var desc = this.desc;
            this.afdb.object('posts/' + "".concat(this.user.getUID())).set({
              image: image,
              desc: desc
            });
          }
        }]);

        return UploaderPage;
      }();

      UploaderPage.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
        }, {
          type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_5__["AngularFirestore"]
        }, {
          type: _user_service__WEBPACK_IMPORTED_MODULE_6__["UserService"]
        }, {
          type: _angular_fire_database__WEBPACK_IMPORTED_MODULE_7__["AngularFireDatabase"]
        }];
      };

      UploaderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-uploader',
        template: _raw_loader_uploader_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_uploader_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], UploaderPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=uploader-uploader-module-es5.js.map